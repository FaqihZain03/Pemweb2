<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>Data Mobil</h1>
    <table>
        <thead>
            <tr>
                <th>Nomor</th>
                <th>Nama Mobil</th>
                <th>Merk Mobil</th>
                <th>CC</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $dataMobil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mobil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($mobil['nama_mobil']); ?></td>
                <td><?php echo e($mobil['merkMobil']); ?></td>
                <td><?php echo e($mobil['cc']); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
</body>
</html><?php /**PATH C:\xampp\htdocs\Pemweb2\rentalmobil\resources\views/mobil/index.blade.php ENDPATH**/ ?>